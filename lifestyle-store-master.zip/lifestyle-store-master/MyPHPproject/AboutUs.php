<!DOCTYPE html>
<html>
<head>        
<title>About Us</title>  
    <link rel="stylesheet" href="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/css/bootstrap.min.css">
      <script type="text/javascript" src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.4/jquery.min.js"></script>
        <script type="text/javascript" src="https://maxcdn.bootstrapcdn.com/bootstrap/3.3.7/js/bootstrap.min.js"> </script>

     <link href="index.css" rel="stylesheet" type="text/css"/>
</head>
<body>
<div class="navbar navbar-inverse navbar-fixed-top">
<div class="container">
  <div class="navbar-header">
    <button type="button" class="navbar-toggle" data-toggle="collapse" datatarget="#myNavbar">
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
      <span class="icon-bar"></span>
    </button>
    <a class="navbar-brand" href="index.php">E-Store</a>
  </div>
  <div class="collapse navbar-collapse" id="myNavbar">
    <ul class="nav navbar-nav navbar-right">
        <li><a href="SignUp.php"><span class="glyphicon glyphicon-user"></span> Sign Up</a></li>
        <li><a href="Login.php"><span class="glyphicon glyphicon-log-in"></span> LogIn</a></li>
        <li><a href = "AboutUs.php"><span class = "glyphicon glyphicon-th-list"></span> About Us</a></li>
        <li><a href = "ContactUs.php"><span class = "glyphicon glyphicon-phone"></span> Contact Us</a></li>

    </ul>
  </div>
</div>
</div>
  
<br>
<br><br>        

<div class="container">           
<div class="col-sm-4">
<div class="panel panel-default">                   
<div class="panel-body">                    
<h3 style="color:orange" class="color">WHO WE ARE</h3>                    
<img src="about-img.jpg" alt="about image"><br><br>
                    
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout. The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).The point of using Lorem Ipsum is that it has a more-or-less normal distribution of letters, as opposed to using 'Content here, content here', making it look like readable English. Many desktop publishing packages and web page editors now use Lorem Ipsum as their default model text, and a search for 'lorem ipsum' will uncover many web sites still in their infancy. Various versions have evolved over the years, sometimes by accident, sometimes on purpose (injected humour and the like).<p>
                
</div>                
</div>      
</div>
            
<div class="col-sm-4">                
<div class="panel panel-default">                   
<div class="panel-body">                    
<h3 style="color:orange" class="color">OUR HISTORY</h3><br><br>                    
<h4 style="color:blue">1988&#45;</h4>                    
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                    
<br>
                    
<h4 style="color:blue">2002&#45;</h4>                    
<p>Lorem Ipsum is simply dummy text of the printing and typesetting industry. Lorem Ipsum has been the industry's standard dummy text ever since the 1500s, when an unknown printer took a galley of type and scrambled it to make a type specimen book. It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                    
<br>                    
<h4 style="color:blue">2016&#45;</h4>                    
<p>It has survived not only five centuries, but also the leap into electronic typesetting, remaining essentially unchanged. It was popularised in the 1960s with the release of Letraset sheets containing Lorem Ipsum passages, and more recently with desktop publishing software like Aldus PageMaker including versions of Lorem Ipsum. It is a long established fact that a reader will be distracted by the readable content of a page when looking at its layout.</p>
                    
</div>                
</div>                
</div>            
<div class="col-sm-4">
<div class="panel panel-default">                   
<div class="panel-body">                    
<h3 style="color:orange" class="color">OPPORTUNITIES</h3><br><br>                        
<b>Available Roles</b>
                            
<ol>
                                
<li>Jr./Sr. Web Developer [Full Time Role + also available as a 6 Months Internships]</li>
                                
<li>Bussiness Apprentise [6 Months Internships]</li>
                                
<li>Manager at backend operations[Full Time Role + also available as a 6 Months Internships]</li>
                            
</ol>
                        
</div>                
</div>            
</div>
</div>
        
<footer>
  <div class="container">
<center><p>Copyright © E-Store. All Rights Reserved | Contact Us: +91 90000 00000</p></center>
  </div>
</footer>
   
 </body>

</html>
